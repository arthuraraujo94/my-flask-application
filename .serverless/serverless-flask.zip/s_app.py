import serverless_sdk
sdk = serverless_sdk.SDK(
    tenant_id='arthuraraujo',
    application_name='webapp-app',
    app_uid='cvZyhZ8cJfmJFDjTqn',
    tenant_uid='5jkMmBJFs2Yy7XhFS3',
    deployment_uid='b08c2d93-2214-4ae5-9b29-3c6a70901037',
    service_name='serverless-flask',
    stage_name='dev'
)
handler_wrapper_kwargs = {'function_name': 'serverless-flask-dev-app', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('wsgi_handler.handler')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
